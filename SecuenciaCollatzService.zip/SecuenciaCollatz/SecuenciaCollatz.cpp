// SecuenciaCollatz.cpp : Archivo con la implementaci�n del web service.
// Autor : Michaelle Arias

#include "stdafx.h"
#include <list>
#include "rapidjson/document.h"
#include "rapidjson/stringbuffer.h"
#include "rapidjson/writer.h"

using namespace System;
using namespace System::Web;
using namespace System::Web::Services;
using namespace std;
using namespace rapidjson;

namespace SecuenciaCollatzService {

	[WebService(Namespace = L"http://tempuri.org/")]
	[WebServiceBinding(ConformsTo = WsiProfiles::BasicProfile1_1)]

	public ref class SecuenciaCollatzService : public WebService
	{
		public:

			[WebMethod(Description = L"Devuelve la secuencia de Collatz para un n�mero dado.")]
			void SecuenciaCollatz(long numero)
			{
				list<long> numsOut;
				numsOut = secCollatz(numero, numsOut);
				Document d;
				d.SetObject();
				Document::AllocatorType& allocator = d.GetAllocator();
				Value jsonArray(kArrayType);

				for (int num : numsOut) {
					jsonArray.PushBack(Value().SetInt(num), allocator);
				}

				d.AddMember("secuenciaCollatz", jsonArray, allocator);
				StringBuffer buffer;
				Writer<StringBuffer> writer(buffer);
				d.Accept(writer);

				Context->Response->Write(gcnew String(buffer.GetString()));
			}

		private:
			//funci�n recursiva que calcula la secuencia de collatz de un n�mero.
			list<long> secCollatz(long num, list<long> numsOut)
			{
				//la secuencia de collatz termina en 1...
				if (num == 1)
					numsOut.push_back(num);

				//si es menor o igual a 1 la secuencia termina...
				if (num <= 1)
					return numsOut;

				//agrego el n�mero actual...
				numsOut.push_back(num);

				//condici�n par e impar, aqu� el n�mero cambia...
				if (num % 2 == 0)
					num = num / 2;
				else
					num = (num * 3) + 1;

				//la secuencia es recursiva hasta que el n�mero sea 1...
				return secCollatz(num, numsOut);
			}
	};
}
